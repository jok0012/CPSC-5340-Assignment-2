
import SwiftUI

//main model

struct Smoothie: Identifiable {
    let id: String
    let name: String
    let subtitle: String
    let description: String
    let price: Double
    let emoji: String
    let tint: Color

    static let menu: [Smoothie] = [
        Smoothie(
            id: "green",
            name: "The Greenwashing",
            subtitle: "Nature's little loophole",
            description: "Vanilla ice cream, banana, oat milk, a handful of spinach for legal reasons, and a whisper of kale.",
            price: 8.50,
            emoji: "🥬",
            tint: Color(red: 0.80, green: 0.87, blue: 0.65)
        ),
        Smoothie(
            id: "cacao",
            name: "Espresso Cacao Power",
            subtitle: "Rise, grind, and reconsider",
            description: "Chocolate ice cream, malted milk, dark chocolate ribbons, and our entirely fictional 500mg caffeine energy mix. Please do not actually drink this.",
            price: 9.75,
            emoji: "🍫",
            tint: Color(red: 0.77, green: 0.59, blue: 0.48)
        ),
        Smoothie(
            id: "berry",
            name: "Antioxidant Alibi",
            subtitle: "Fruit wearing a disguise",
            description: "Strawberry ice cream, raspberry syrup, whole milk, whipped cream, and exactly three blueberries for credibility.",
            price: 8.95,
            emoji: "🍓",
            tint: Color(red: 0.94, green: 0.68, blue: 0.72)
        ),
        Smoothie(
            id: "tropical",
            name: "Tropical Wellness Retreat",
            subtitle: "Vacation calories don't count",
            description: "Mango sorbet, coconut ice cream, pineapple juice, vanilla cream, and a tiny umbrella doing all the heavy lifting.",
            price: 9.25,
            emoji: "🍍",
            tint: Color(red: 0.98, green: 0.81, blue: 0.43)
        )
    ]
}

//main screen

struct ContentView: View {
    @State private var quantities: [String: Int] = [:]
    @State private var wellnessDust = false
    @State private var showConfirmation = false
    @State private var submittedOrderMessage = ""

    private let backgroundColor = Color(
        red: 0.97, green: 0.96, blue: 0.91
    )
    private let inkColor = Color(
        red: 0.17, green: 0.23, blue: 0.18
    )
    private let accentColor = Color(
        red: 0.30, green: 0.40, blue: 0.29
    )

    private let dustPrice = 1.25

    private var itemCount: Int {
        Smoothie.menu.reduce(0) {
            $0 + quantities[$1.id, default: 0]
        }
    }

    private var subtotal: Double {
        Smoothie.menu.reduce(0) { total, smoothie in
            total + smoothie.price *
                Double(quantities[smoothie.id, default: 0])
        }
    }

    private var total: Double {
        subtotal + (wellnessDust
            ? Double(itemCount) * dustPrice
            : 0)
    }

    private var confirmationMessage: String {
        let order = Smoothie.menu
            .filter { quantities[$0.id, default: 0] > 0 }
            .map {
                "\($0.name) × \(quantities[$0.id, default: 0])"
            }
            .joined(separator: "\n")

        let dustNote = wellnessDust
            ? "\nWellness Dust included. Your aura is thriving."
            : ""

        return "\(order)\(dustNote)\n\nTotal: \(money(total))\n\nYour questionable wellness journey starts now."
    }

    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    header
                    heroCard
                    menuSection
                    wellnessOption
                    checkoutSection

                    Text("100% vibes. Questionable amounts of fruit.")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(inkColor.opacity(0.55))
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 24)
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
            }
        }
        .foregroundStyle(inkColor)
        .alert(
            "Order sent to the blender!",
            isPresented: $showConfirmation
        ) {
            Button("Deliciously questionable", role: .cancel) { }
        } message: {
            Text(submittedOrderMessage)
        }
    }

    //the header

    private var header: some View {
        HStack(alignment: .center) {
            HStack(spacing: 8) {
                Image(systemName: "leaf.fill")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(accentColor)

                VStack(alignment: .leading, spacing: 0) {
                    Text("BLEND IT")
                        .font(.system(size: 19, weight: .black,
                                      design: .rounded))
                        .tracking(1.5)

                    Text("LIKE YOU MEAN IT")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(2.0)
                }
            }

            Spacer()

            Text("WELLNESS™")
                .font(.system(size: 10, weight: .heavy))
                .tracking(1)
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(.white.opacity(0.75))
                .clipShape(Capsule())
        }
    }

    //hero banner

private var heroCard: some View {
    VStack(alignment: .leading, spacing: 0) {
        GeometryReader { geometry in
            ZStack(alignment: .bottomLeading) {
                Image("healthysmoothies")
                    .resizable()
                    .scaledToFill()
                    .frame(
                        width: geometry.size.width,
                        height: 235
                    )
                    .clipped()

                LinearGradient(
                    colors: [.clear, .black.opacity(0.78)],
                    startPoint: .center,
                    endPoint: .bottom
                )

                VStack(alignment: .leading, spacing: 7) {
                    Text("BLENDIT™ · WELLNESS, APPARENTLY")
                        .font(.system(size: 9, weight: .heavy))
                        .tracking(1.2)
                        .foregroundStyle(.white.opacity(0.9))

                    Text("Health starts here.*")
                        .font(.system(
                            size: 32,
                            weight: .black,
                            design: .rounded
                        ))
                        .foregroundStyle(.white)
                        .minimumScaleFactor(0.75)
                        .lineLimit(1)
                }
                .padding(20)
            }
            .frame(width: geometry.size.width, height: 235)
            .clipped()
        }
        .frame(height: 235)

        VStack(alignment: .leading, spacing: 9) {
            Text("*BlendIt is not liable for any degradation in health as a result of our products.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Text("100% wellness-coded. 0% shame.")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(accentColor)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white)
    }
    .frame(maxWidth: .infinity)
    .clipShape(RoundedRectangle(cornerRadius: 24))
}

    //menu

    private var menuSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("THE MENU")
                        .font(.system(size: 10, weight: .heavy))
                        .tracking(2)
                        .foregroundStyle(accentColor)

                    Text("Sip responsibly-ish.")
                        .font(.system(size: 25, weight: .black,
                                      design: .rounded))
                }

                Spacer()

                Text("\(itemCount) SELECTED")
                    .font(.system(size: 9, weight: .heavy))
                    .tracking(0.8)
                    .foregroundStyle(accentColor)
                    .padding(.bottom, 4)
            }

            ForEach(Smoothie.menu) { smoothie in
                SmoothieCard(
                    smoothie: smoothie,
                    quantity: quantityBinding(for: smoothie)
                )
            }
        }
    }

    //conditional extra

    private var wellnessOption: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("MAKE IT EXTRA")
                .font(.system(size: 10, weight: .heavy))
                .tracking(2)
                .foregroundStyle(accentColor)

            Toggle(isOn: $wellnessDust.animation(.easeInOut)) {
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 13)
                            .fill(Color(red: 0.89, green: 0.84, blue: 0.67))
                            .frame(width: 48, height: 48)

                        Image(systemName: "sparkles")
                            .font(.system(size: 21, weight: .semibold))
                            .foregroundStyle(accentColor)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        Text("Wellness Dust")
                            .font(.system(size: 15, weight: .bold))

                        Text("A sprinkle of chia and expensive optimism")
                            .font(.system(size: 11))
                            .foregroundStyle(.secondary)

                        Text("+$1.25 per smoothie")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(accentColor)
                    }
                }
            }
            .tint(accentColor)

            // Conditional UI: this message appears only when the extra is enabled.
            if wellnessDust {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "checkmark.seal.fill")
                    Text("Excellent choice. Your smoothie now has a backstory about ancient superfoods.")
                }
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(accentColor)
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accentColor.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(18)
        .background(.white.opacity(0.75))
        .clipShape(RoundedRectangle(cornerRadius: 22))
    }

    //checkout

    private var checkoutSection: some View {
        VStack(spacing: 14) {
            HStack {
                Text("YOUR WELLNESS INVESTMENT")
                    .font(.system(size: 10, weight: .heavy))
                    .tracking(1)

                Spacer()

                Text("\(itemCount) item\(itemCount == 1 ? "" : "s")")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(.secondary)
            }

            Divider()

            HStack {
                Text("Smoothies")
                    .font(.system(size: 13))

                Spacer()

                Text(money(subtotal))
                    .font(.system(size: 13, weight: .medium))
            }

            if wellnessDust && itemCount > 0 {
                HStack {
                    Text("Wellness Dust")
                        .font(.system(size: 13))

                    Spacer()

                    Text(money(Double(itemCount) * dustPrice))
                        .font(.system(size: 13, weight: .medium))
                }
                .transition(.opacity)
            }

            HStack(alignment: .firstTextBaseline) {
                Text("TOTAL")
                    .font(.system(size: 13, weight: .black))
                    .tracking(1.5)

                Spacer()

                Text(money(total))
                    .font(.system(size: 30, weight: .black,
                                  design: .rounded))
                    .contentTransition(.numericText())
            }

            Button {
                submittedOrderMessage = confirmationMessage
                showConfirmation = true
                quantities = [:]
                wellnessDust = false
            } label: {
                HStack(spacing: 10) {
                    Text("MANIFEST MY SMOOTHIE")
                    Image(systemName: "arrow.right")
                }
                .font(.system(size: 12, weight: .heavy))
                .tracking(0.8)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(
                    itemCount > 0 ? accentColor : Color.gray.opacity(0.4)
                )
                .clipShape(Capsule())
            }
            .disabled(itemCount == 0)

            Text("By ordering, you agree that fruit names are doing a lot of work here.")
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(20)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 24))
    }

    //helpers

    private func quantityBinding(for smoothie: Smoothie) -> Binding<Int> {
        Binding(
            get: { quantities[smoothie.id, default: 0] },
            set: { quantities[smoothie.id] = $0 }
        )
    }

    private func money(_ amount: Double) -> String {
        amount.formatted(.currency(code: "USD"))
    }
}

//reusable menu card

struct SmoothieCard: View {
    let smoothie: Smoothie
    @Binding var quantity: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 18)
                        .fill(smoothie.tint)
                        .frame(width: 82, height: 94)

                    VStack(spacing: 3) {
                        Text(smoothie.emoji)
                            .font(.system(size: 35))

                        Image(systemName: "sparkles")
                            .font(.system(size: 10, weight: .bold))
                    }
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(smoothie.subtitle.uppercased())
                        .font(.system(size: 8, weight: .heavy))
                        .tracking(1)
                        .foregroundStyle(.secondary)

                    Text(smoothie.name)
                        .font(.system(size: 17, weight: .black,
                                      design: .rounded))
                        .fixedSize(horizontal: false, vertical: true)

                    Text(smoothie.description)
                        .font(.system(size: 11))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)

                    Text(smoothie.price.formatted(.currency(code: "USD")))
                        .font(.system(size: 15, weight: .heavy))
                        .foregroundStyle(Color(red: 0.30, green: 0.40, blue: 0.29))
                        .padding(.top, 2)
                }

                Spacer(minLength: 0)
            }

            Divider()

            HStack {
                Text(quantity == 0 ? "Add to your journey" : "In your wellness plan")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)

                Spacer()

                // New UI feature explored: SwiftUI Stepper lets users
                // increase or decrease each item's quantity.
                Stepper(
                    "\(quantity)",
                    value: $quantity,
                    in: 0...10
                )
                .fixedSize()
                .font(.system(size: 12, weight: .bold))
            }
        }
        .padding(16)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay {
            RoundedRectangle(cornerRadius: 22)
                .stroke(smoothie.tint.opacity(0.7), lineWidth: 1)
        }
    }
}

//preview

#Preview {
    ContentView()
}
