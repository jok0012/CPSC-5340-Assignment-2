//
//  BlendItApp.swift
//  BlendIt
//
//  Created by user948560 on 10/25/26.
//

import SwiftUI

@main
struct BlendItApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
